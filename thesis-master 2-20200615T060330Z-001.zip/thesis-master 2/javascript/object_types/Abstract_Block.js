
class Abstract_Block extends Block{
    
}