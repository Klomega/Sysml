
class Link {

    
    /**
     * 
     * @param {Assoc_Block} assoc_block 
     * @param {Part} from 
     * @param {Part} to 
     */
    constructor(assoc_block, from, to) {
        this.assoc_block = assoc_block;
        this.from = from;
        this.to = to;
    }



    
}